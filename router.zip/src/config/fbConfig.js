import firebase from "firebase";
import "firebase/firestore";
import "firebase/auth";

var config = {
    apiKey: "AIzaSyDOB6JMeVO-kGbJj3S01__-NttRiHpzqPk",
    authDomain: "net-ninka.firebaseapp.com",
    projectId: "net-ninka",
    storageBucket: "net-ninka.appspot.com",
    messagingSenderId: "866211231471",
    appId: "1:866211231471:web:5a9d39b4f92cb75ddbcd1a",
    measurementId: "G-14HKCLT5RR"
};

firebase.initializeApp(config);
firebase.firestore().settings({timestampsInSnapshots: true});

export default firebase;