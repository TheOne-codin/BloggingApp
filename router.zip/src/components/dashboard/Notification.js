import React from "react";
const Notification = (props) => {
    return(
        <div className="section right">
            <div className="card z-depth-0">
                <div className="card-content">
                    <span className="card-title">Notifications</span>
                    <ul className="notifications">
                        <li><span className="red-text"> Not available </span> for it being functionable via paid service </li>
                    </ul>
                </div>
            </div>


        </div>
    )
}

export default Notification