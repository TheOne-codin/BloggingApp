import React, {Component} from 'react'
// import axios from 'axios';
import { connect } from "react-redux";
class Post extends Component{
    render(){
        console.log(this.post);
        const post = this.props.post ? (
            <div className="post">
                <h4 className="center">{this.props.post.title}</h4>
                <p>{this.props.post.body}</p>
                <button onClick="delete">Delete</button>
            </div>
        ) : (
            <div className="center">Loading post...</div>
        )
        
        return(
            <div className="container">
            {post}
            </div>
        )
    }
}
const mapStatetoProps= (state, ownProps) => {
    const id = parseInt(ownProps.match.params.post_id);
    // console.log(ownProps.match.params.post_id);
    // console.log(state.posts)
    return{
        post: state.posts.find(post => post.id === id )
    }
}
export default connect(mapStatetoProps)(Post)